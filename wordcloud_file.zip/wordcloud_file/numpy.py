import numpy as np
a = np.array([1,2,3])   #넘파이 객체 생성
print(a.shape)  #객체의 형태
print(a.ndim)   #객체의 차원
print(a.dtype)  #객체의 내부 자료형
print(a.itemsize)   #객체의 메모리 크기(byte)
print(a.size)   #객체의 전체 크기(항목수)

